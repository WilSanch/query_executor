# Query Executor API

API para ejecutar queries asociados a aplicaciones y almacenar resultados en Azure Blob Storage.
